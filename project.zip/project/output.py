Python 3.12.2 (tags/v3.12.2:6abddd9, Feb  6 2024, 21:26:36) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\dell\AppData\Local\Programs\Python\Python312\project-3.2.py
3
naga
219
4 5 6 7
nv
216
2 5 7 9
rama
220
4 8 2 6
name		rollno		marks		total
{'name': 'naga', 'rollno': 219, 'marks': [4, 5, 6, 7], 'total': 22}
{'name': 'nv', 'rollno': 216, 'marks': [2, 5, 7, 9], 'total': 23}
{'name': 'rama', 'rollno': 220, 'marks': [4, 8, 2, 6], 'total': 20}
   name  rollno         marks  total
0  naga     219  [4, 5, 6, 7]     22
1    nv     216  [2, 5, 7, 9]     23
2  rama     220  [4, 8, 2, 6]     20
max total=: 23
min total=: 20
sort total=: [20, 22, 23]
{20, 22, 23}
maximum score of student1: 7
minimum score of student1: 4
total score of student1: 22
average score of student1: 22
sort of all marks1: [4, 5, 6, 7]
maximum score of student2: 9
minimum score of student2: 2
total score of student2: 23
average score of student2: 23
sort of all marks2: [2, 5, 7, 9]
maximum score of student3: 8
minimum score of student3: 2
total score of student3: 20
average score of student3: 20
sort of all marks3: [2, 4, 6, 8]
maximum marks in subject 1: 4
maximum marks in subject 2: 5
maximum marks in subject 3: 7
maximum marks in subject 4: 9
