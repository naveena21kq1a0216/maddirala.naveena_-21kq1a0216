import pandas as pd
s=[]
def add_student(name,rollno,marks,total):
    student={
        'name':name,
        'rollno':rollno,
        'marks':marks,
        'total':total
    }
    s.append(student)
n=int(input())
for i in range(n):
    name=input()
    rollno=int(input())
    marks=list(map(int,input().split()))
    total=sum(marks)
    add_student(name,rollno,marks,total)
print('name\t\trollno\t\tmarks\t\ttotal')
for i in range(n):
    print(s[i])
df=pd.DataFrame(s)
print(df)
b=[]
for j in range(n):
    a=s[j]['total']
    b.append(a)
print('max total=:',max(b))
print('min total=:',min(b))
b.sort()
print('sort total=:',b)
print(set(b))
c=[]
for k in range(n):
    d=s[k]['marks']
    c.append(d)
for p in range(n):
    print(f'maximum score of student{p+1}:',max(c[p]))
    print(f'minimum score of student{p+1}:',min(c[p]))
    print(f'total score of student{p+1}:',sum(c[p]))
    print(f'average score of student{p+1}:',sum(c[p]))
    c[p].sort()
    print(f'sort of all marks{p+1}:',c[p])
m=[]
for j in range(len(marks)):
    for i in range(n):
        m.append(s[i]['marks'][j])
    print(f'maximum marks in subject {j+1}:',max(m))
    m.clear()
    



    
